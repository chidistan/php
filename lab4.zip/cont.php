<?php
   // var_dump($_POST);
    $firstName= $fnamer= $lastName= $lnamer= $telephone= $telephoner= $email= $emailer = "";
    $cars = array("Toyota", "Honda", "Infinity", "Audi","Subaru", "Ford", "Nissan", "Chevrolet","Mercedes", "BMW", "Hyundai", "Lexus");

    function get($name) {
        return isset($_REQUEST[$name]) ? $_REQUEST[$name] : '';
    }
    function is_valid_index($index, $array) {
         return $index >= 0 && $index < count($array);

    }
        if(get('cars')) {
            $cars_id = get('cars');
            if(is_valid_index($cars_id-1, $cars)) {

            }
            else {
                echo "<span style='color: red'> Select a Vehicle brand </span>";
            }

        }
if($_SERVER['REQUEST_METHOD'] == "POST") {

         if (isset($_POST['register'])) {
             $firstName = $_POST['firstName'];
             $lastName = $_POST['lastName'];
             $telephone = $_POST['telephone'];
             $email = $_POST['email'];
             $pattern = "/[a-zA-Z]{4,9}/";
             $patternPhone = "/^[0-9]{3}[0-9]{3}[0-9]{4}$/";

             if (empty($firstName)) {
                 $fnamer = "Please enter your first name";
             } elseif (!preg_match($pattern, $firstName)) {
                 $fnamer = "Only letters are allowed";
             } else {
                 $fnamer = "";
             }

             if (empty($lastName)) {
                 $lnamer = "Please enter your last name";
             } elseif (!preg_match($pattern, $lastName)) {
                 $lnamer = "Only letters are allowed";
             } else {
                 $lnamer = "";
             }

             if (empty($email)) {
                 $emailer = "please enter email";
             } elseif (!filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL)) {
                 $emailer = "Please enter valid email";
             } else {
                 $emailer = "";
             }

             if (empty($telephone)) {
                 $telephoner = "Please enter phone number";
             } elseif (!preg_match($patternPhone, $telephone)) {
                 $telephoner = "Please enter correct phone number";
             } else {
                 $telephoner = "";
             }

            if(empty($fnamer)&& empty($lnamer)&& empty($telephoner)&& empty($emailer)) {
                header("location: process.php");
            }

         }
     }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Account Sign Up</title>


    <style>

        #form{
            text-align: center;
            background-color: transparent;
        }
        input{
            margin-bottom: 7px;

        }
        .error {color: #FF0000;}
    </style>

</head>

<body>
<div id="form">
    <p><span class="error"></span></p>
    <h2>Your Information</h2>
    <form method="post">
        First Name:
        <input type="text" name="firstName"  id="fname" value="<?php if(empty($fnamer)) {
            echo $firstName;} ?>"  /><span class="error"> <?php echo $fnamer;?></span><br>
        Last Name:
        <input type="
            }text" name="lastName" id="lname" value="<?php if(empty($lnamer)) {
            echo $lastName;} ?>"  /> <span class="error"> <?php echo $lnamer;?></span><br>
        Telephone:
        <input type="text" name="telephone" id="tele" maxlength="13" value="<?php if(empty($telephoner)) {
            echo $telephone;} ?>"  /> <span class="error"><?php echo $telephoner;?> </span><br>
        Email:
        <input type="text" name="email" id="emailId" maxlength="25" value="<?php if(empty($emailer)) {
            echo $email;} ?>"  /><span class="error"> <?php echo $emailer; ?> </span><br>
        Vehicle Model:
        <select id="drop" name="cars" size="1">
            <option selected="selected" ></option>
            <?php
            foreach ($cars as $ca) {?>
                <option value="<?php echo $ca; ?>"><?php echo $ca; ?></option>
                <?php
            }
            ?><span class="error"></span>
         <br>
         <input type="submit" value="Sumbit" name ="register">

    </form>
</div>
</body>
</html>