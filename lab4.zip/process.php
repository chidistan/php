<!DOCTYPE html>
<html lang="en">
    
    <head>
    <meta charset="UTF-8">
     <title>Lab 2</title>
    </head>
    <body>
        <style>
    h1{
        text-align: center;
        font-weight: bolder;
        font-style: italic;
        color: firebrick;
        margin-top: 170px;
    }

</style>


<h1> THANK YOU FOR REGISTERING!!!</h1>
        
        </body>
    </html>