<style>
    div{
        background-color: transparent;
        text-align: center;
    }
    h1{
        color: rebeccapurple;
    }
    h4{
        color: cornflowerblue;
    }
    img{
        float: left;
        padding-left: 30px;
    }
    
</style>
<div>
<img src="logo.png" alt="logo" width="150px" height="150px">
<h1> Stanfield Global Limited</h1>
<h4>40 Heaven Blvd, Toronto Ontario</h4>
<h4>Tel: +1-647-770-2197</h4>
<h4>email: stanfieldglobal@gmail.com</h4>
</div>