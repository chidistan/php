<!DOCTYPE html>
<html lang="en">
<style>
    body{
        width: 700px;
        margin-left: 250px;
        background-color: aquamarine;
    }

</style>
    
    <head>
    <meta charset="UTF-8">
     <title>Lab 2</title>
    </head>
    <body>
    
        <?php include 'labheader.php'; ?>
        <?php include 'navigation.php'; ?>
        <?php include 'cont.php'; ?>
        <?php include 'lapfooter.php'; ?>
    </body>
    </html>