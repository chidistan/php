<style>
    #foot {
        
        text-align: center;
    }
    h3 {
        font-style: italic;
        color: crimson;
    }
</style>
<div id="foot">
<h3>Bringing services to your doorstep....</h3>
<h4>Dealers in all types of cars and trucks </h4>
<a href="about.php"> About Us</a>
<?php require_once "navigation.php";
echo display_navigation();
?>
<p>&copy 2018 Stanfield global limited </p>
</div>