<style>
    a{
        color: black;
        font-weight: bold;
        padding-left: 40px;
    }

</style>

<?php
function display_navigation()
{
    $links = array(array("Google", "//google.com"), array("Mercedes_Benz", "//mercedes-benz.com"),
        array("Toyota", "//toyota.com"), array("Honda", "//honda.com"), array("Ford", "//ford.com"),
        array("Nissan", "//nissan.com"));
    foreach ($links as $url) {
        echo "<a href='" . $url[1] . "'>" . $url[0] . "" . "" . "" . " </a>"."";
    }
}

    echo display_navigation();

?>